import uuid
import os
import logging
import torch
from transformers import AutoProcessor, MusicgenForConditionalGeneration
import boto3
import scipy


# DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

logger = logging.getLogger(__name__)


def model_fn(model_dir, device):
    '''loads model'''
    model = MusicgenForConditionalGeneration.from_pretrained("facebook/musicgen-large")
    #model.to(DEVICE)
    return model


def _process_input(data):
    # defaults
    default_generation_params = {
        'guidance_scale': 3,
        'max_new_tokens': 256,
        'do_sample': True,
        'temperature': 1 
        }
    default_texts = ["Morning sunshine, beats, ukelele, happy swings"]
    # obtain input data
    texts = data.get('texts', default_texts)
    config = data.get('generation_params', default_generation_params)
    guidance_scale = config.get('guidance_scale', default_generation_params.get('guidance_scale'))
    max_new_tokens = config.get('max_new_tokens', default_generation_params.get('max_new_tokens'))
    temperature = config.get('temperature', default_generation_params.get('temperature'))
    do_sample = config.get('do_sample', default_generation_params.get('do_sample'))
    generation_params = {
        'guidance_scale': guidance_scale, 
        'do_sample': do_sample,
        'max_new_tokens': max_new_tokens,
        'temperature': temperature
    }
    return texts, generation_params


def _upload_to_s3(wav_on_disk, bucket_name):
    # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/object/upload_fileobj.html
    target_file = wav_on_disk.split('/')[-1]
    prefix = 'musicgen_large/output'
    key = f'{prefix}/{target_file}'

    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    obj = bucket.Object(key)

    with open(wav_on_disk, 'rb') as data:
        obj.upload_fileobj(data)

    return f"s3://{obj.bucket_name}/{obj.key}"


def _upload_wav_files(disk_wav_locations, bucket_name):
    upload_paths = []
    for loc in disk_wav_locations:
        try:
            uri = _upload_to_s3(loc, bucket_name)
            upload_paths.append(uri)
        except Exception as e:
            logger.exception('error uploading %s: %s', loc, e)

    return upload_paths


def _write_wavs_to_disk(sampling_rate, audio_values):
    r = len(audio_values)
    prefix = str(uuid.uuid1())
    disk_wav_locations = []
    for i in range(r):
        # Write wav to Disk
        wav_file = f"{prefix}_{i}_musicgen_large_out.wav"
        wav_on_disk = f'/tmp/{wav_file}'
        scipy.io.wavfile.write(wav_on_disk,
                                rate=sampling_rate,
                                data=audio_values[i, 0].cpu().numpy()
                            )
        disk_wav_locations.append(wav_on_disk)
    return disk_wav_locations


def _delete_file_on_disk(filename):
    if os.path.isfile(filename):
        os.remove(filename)


def predict_fn(data, model):
    '''generates the music from the input data'''
    result_dict = {
            "generated_outputs_s3": []
        }
    try:
        # https://sagemaker.readthedocs.io/en/stable/api/inference/predictors.html#sagemaker.predictor.Predictor.predict
        bucket_name = data.pop('bucket_name', None)
        if not bucket_name:
            raise ValueError("bucket_name is required ex: sagemaker_default_bucket_007")
        texts, generation_params = _process_input(data)
        processor = AutoProcessor.from_pretrained("facebook/musicgen-large")
        inputs = processor(
            text = texts,
            padding=True,
            return_tensors="pt",
        )
        logger.info('start generate music')
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model.to(device)
        audio_values = model.generate(**inputs.to(device),
                                      **generation_params)

        logger.info('end generate music')
        # process generated output audio_values
        sampling_rate = model.config.audio_encoder.sampling_rate

        disk_wav_locations = _write_wavs_to_disk(sampling_rate, audio_values)

        # Upload wavs to S3
        result_dict["generated_outputs_s3"] = _upload_wav_files(disk_wav_locations, bucket_name)
        # Clean up disk
        for wav_on_disk in disk_wav_locations:
            _delete_file_on_disk(wav_on_disk)
    except Exception as e:
        logger.exception('error while prediction: %s', e)

    logger.info('end predict_fn')
    return result_dict
